package dev.emi.trinkets.mixin.accessor;

import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * You'll access widen this into being accessible but won't make its field accessible? Yes.
 */
@Mixin(class_484.class)
public interface CreativeSlotAccessor {
	
	@Accessor("slot")
	public Slot getSlot();
}
