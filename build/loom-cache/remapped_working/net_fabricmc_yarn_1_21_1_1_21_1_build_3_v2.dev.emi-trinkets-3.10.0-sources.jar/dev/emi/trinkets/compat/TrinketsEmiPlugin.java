package dev.emi.trinkets.compat;

import dev.emi.emi.api.EmiPlugin;
import dev.emi.emi.api.EmiRegistry;
import dev.emi.emi.api.widget.Bounds;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;

public class TrinketsEmiPlugin implements EmiPlugin {

	@Override
	public void register(EmiRegistry registry) {
		registry.addExclusionArea(InventoryScreen.class, (screen, consumer) -> {
			for (class_768 rect2i : TrinketsExclusionAreas.create(screen)) {
				consumer.accept(new Bounds(rect2i.method_3321(), rect2i.method_3322(), rect2i.method_3319(),
					rect2i.method_3320()));
			}
		});
		registry.addExclusionArea(CreativeInventoryScreen.class, (screen, consumer) -> {
			for (class_768 rect2i : TrinketsExclusionAreas.create(screen)) {
				consumer.accept(new Bounds(rect2i.method_3321(), rect2i.method_3322(), rect2i.method_3319(),
					rect2i.method_3320()));
			}
		});
	}
}
